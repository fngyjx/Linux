<?php 

include('global.php');
require_ssl();

if ( isset($_GET['out']) ) {
	setCookie("user_id","", time()-"100");
	setCookie("uNameCookie", "" , time()-"100");
	setCookie("uLoggedInCookie", "" , time()-"100");
	setCookie("first_nameCookie", "" , time()-"100");
	setCookie("last_nameCookie", "" , time()-"100");
	setCookie("log_nameCookie", "" , time()-"100");
	setCookie("purgeTempCookie", "" , time()-"100");
	setCookie("userTypeCookie","", time()-"100");
	header ("Location: index.php");
	exit;
}

$uName = $_POST['email'];
$uPassword = $_POST['pass'];

// Verify that the $uName is logging in or already logged in
if ( !isset($_COOKIE['uNameCookie']) ) {
	$new_log = true;
	if ( $uName == "" or $uPassword == "" ) {
		setCookie("user_id","", time()-"100");
		setCookie("uNameCookie", "" , time()-"100");
		setCookie("uPasswordCookie", "" , time()-"100");
		setCookie("uLoggedInCookie", false);
		setCookie("uLevelCookie", "" , time()-"100");
		setCookie("userTypeCookie","", time()-"100");
		header ("Location: index.php?instruction=wologin1&u=" . $_POST['email'] . "&p=" . $_POST['pass']);
		exit;
	}
}

else {
	// if a new $uName is logging in then get new variables else continue
	if ( !empty($_POST) ) {
		$new_log = true;
	}
	elseif ( !isset($_COOKIE['uLoggedInCookie']) ) {
		setCookie("user_id","", time()-"100");
		setCookie("uNameCookie", "" , time()-"100");
		setCookie("uPasswordCookie", "" , time()-"100");
		setCookie("uLoggedInCookie", false);
		setCookie("priv_levelCookie", "" , time()-"100");
		setCookie("userTypeCookie","", time()-"100");
		header ("Location: index.php?instruction=wologin2");
		exit;
	}
	else {
		$uName = $uNameCookie;
		$new_log = false;
	}
}

// if a new user then verify name and password else skip
if ( $new_log == true ) {

	$err = 0;
	
	// sql statement which will determine if $uName exists 
	$sql = "SELECT * FROM users WHERE email = '" . $uName . "'";
	$result = mysql_query($sql, $link) or die (mysql_error()."<br />Couldn't execute query: $sql<BR><BR>");
	$row = mysql_fetch_array($result);

	$iCount = mysql_num_rows($result);

	setCookie("user_id","", time()-"100");
	setCookie("uNameCookie", "" , time()-"100");
	setCookie("uPasswordCookie", "" , time()-"100");
	setCookie("uLoggedInCookie", false);
	setCookie("userTypeCookie","", time()-"100");
	setCookie("priv_levelCookie", "" , time()-"100");

	// if the $uName doesn't exist then send back to login page
	if ( $iCount == 0 ) {
		mysql_close ($link);
		header ("Location: index.php?instruction=incorrect_u_p&sp=1");
		exit;
	}

	// Locked out return to index	
	if ( $row[locked] == 1 ) {
		mysql_close ($link);
		header ("Location: index.php?instruction=lockout");
		exit;
	}

	// inactive out return to index	
	if ( $row[active] == 0 ) {
		mysql_close ($link);
		header ("Location: index.php?instruction=inactive");
		exit;
	}

	// If the password doesn't match then send back to login page
	if ( $row['pass'] != $uPassword ) {
		$FailedLoginAttempts = $row['login_attempts'];
		
		if ( $FailedLoginAttempts >= 4 ) {
			$sql = "UPDATE users SET login_attempts = " . ($FailedLoginAttempts + 1) . ", locked = 1, lockout_date = '" . date("Y-m-d H:i:s") . "' WHERE email = '" . $uName . "'";
			mysql_query($sql, $link);
			mysql_close ($link);
			setCookie("user_id","", time()-"100");
			header ("Location: index.php?instruction=lockout");
			exit;
		}
		else {
			$sql = "UPDATE users SET login_attempts = " . ($FailedLoginAttempts + 1) .  " WHERE email = '" . $uName . "'";
			mysql_query($sql, $link);
			mysql_close ($link);
			setCookie("user_id","", time()-"100");
			header ("Location: index.php?instruction=incorrect_u_p&sp=2&p1=" . $row['password'] . "&p2=" . $uPassword);
			exit;
		}
		
	}

	// set the user session variables

	if ( $err == 0 ) {
		
		setCookie("user_id",$row['user_id']);
		setCookie("first_nameCookie", $row['first_name']);
		setCookie("last_nameCookie", $row['last_name']);
		setCookie("userTypeCookie", $row['user_type']);
		setCookie("uNameCookie", $row['email']);
		setCookie("uLoggedInCookie", true);

		$sql =  "UPDATE users SET last_login = '" . date("Y-m-d H:i:s") . "', login_attempts = 0 WHERE email = '" . $uName . "'";
		mysql_query($sql, $link);
		mysql_close ($link);
	}

	else {
		mysql_close ($link);
		setCookie("user_id","", time()-"100");
		header ("Location: index.php?instruction=error");
		exit;
	}	

}

header ("Location: index.php");

exit;

?>